﻿using System;
using System.Collections.Generic;

namespace Capgemini.Inventory.Helpers
{
    public enum UserType
    {
        Admin, SystemUser, Distributor, Supplier, Anonymous
    }
}



