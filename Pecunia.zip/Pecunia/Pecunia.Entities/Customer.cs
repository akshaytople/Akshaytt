﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capgemini.Pecunia.Helpers.ValidationAttributes;

namespace Pecunia.Entities
{
   public interface ICustomer
    {
        Guid CustomerID { get; set; }
        string CustomerName { get; set; }
        string CustomerAddress { get; set; }
        string CustomerMobile { get; set; }
        string CustomerEmail { get; set; }
        string CustomerPan { get; set; }
        string CustomerAadhaarNumber { get; set; }
        DateTime DOB { get; set; }

    }


    u
    public class Customer : ICustomer
    {
        [Required("CustomerID cannot be blank")]
        public Guid CustomerID { get; set; }

        [Required("CustomerName cannot be blank")]
        [RegExp("[a-zA-Z]$")]
        public string CustomerName { get; set; }

        [Required("CustomerAddress cannot be blank")]
        [RegExp(@"[0-9]+\s+([a-zA-Z]+|[a-zA-Z]+\s[a-zA-Z]+)$")]
        public string CustomerAddress { get; set; }

        [Required("CustomerMobile cannot be blank")]
        [RegExp(@"\+?[0-9]{10}")]
        public  string CustomerMobile { get; set; }

        [Required("CustomerEmail cannot be blank")]
        [RegExp(@"([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$")]
        public string CustomerEmail { get; set; }

        [Required("CustomerPAN cannot be blank")]
        [RegExp(@"([A - Z]{ 5}\d{ 4}[A-Z]{1})$")]
        public string CustomerPan { get; set; }

        [Required("CustomerAadhaarNumber cannot be blank")]
        [RegExp]

        



    }
}
