﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using System.Text.RegularExpressions;
using Pecunia.Exceptions;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Capgemini.Pecunia.Helpers;
using Newtonsoft.Json;

namespace Pecunia.DAL
{
    
    public class CustomerDAL
    {
        public static List<Customer> CustomersList = new List<Customer>(); // list of customers is created by passing CustomerEntities class as data type 
        public bool AddCustomerDAL(Customer customerEntities)
        {
            Guid custID = Guid.NewGuid();
            string customerID = "CUST" + custID.ToString();
            try
            {
                
                customerEntities.CustomerID = custID;
                CustomersList.Add(customerEntities);  //Customer is added in the list        
                return SerialiazeIntoJSON(CustomersList, "Customerdata.txt");
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public bool RemoveCustomerDAL(Guid CustomerID)
        {
            try
            {
                List<Customer> customerlist = DeserializeFromJSON("Customerdata.txt");// deserialize because we have to search list

                foreach (Customer cust in customerlist)  //foreach(dataType variable in collectionName)
                {
                    if (cust.CustomerID.Equals(CustomerID) == true)
                    {
                        customerlist.Remove(cust);
                        SerialiazeIntoJSON(customerlist, "Customerdata.txt");// we serialize because in our original database we have to make the above changes
                        break;
                    }
                }
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public Customer GetCustomerByCustomerID_DAL(Guid CustomerID)
        {
            bool validate = false;
            try
            {
                Customer customerEntitiesTemporary = new Customer();

                List<Customer> custlist = DeserializeFromJSON("Customerdata.txt"); //we have to search customer through CustomerID

                foreach (Customer cust in custlist) //foreach will search the list
                {
                    if (cust.CustomerID.Equals(CustomerID) == true)
                    {
                        validate = true;
                        customerEntitiesTemporary = cust;
                        break;
                    }
                }
                if (validate != true)
                {
                    throw new CustomerDoesNotExistException("Customer Not available based on given CustomerID");
                }
                //if customerID not found

                return customerEntitiesTemporary;
            }
            catch (Exception e)
            {
                Customer c = new Customer();
                return c;
            }
        }

        public List<Customer> GetAllCustomerDAL()
        {
            List<Customer> custlist = DeserializeFromJSON("Customerdata.txt");
            return custlist;
        }


        public void UpdateCustomerByCustomerID_DAL(Customer sourceobject)
        {
            bool validate = false;

            try
            {
                List<Customer> custlist = DeserializeFromJSON("Customerdata.txt");

                foreach (Customer cust in custlist) //stores object not fields

                {
                    if (cust.CustomerID.Equals(sourceobject.CustomerID) == true)
                    {
                        ReflectionHelpers.CopyProperties( sourceobject,cust,new List<string>() { "CustomerName", "CustomerAddress ", "CustomerMobile", "CustomerEmail" } );
                        break;
                    }  
                }
                SerialiazeIntoJSON(custlist, "Customerdata.txt");
            }
            catch (Exception e)
            {
                Console.WriteLine("cannot update");
            }
        }


        public bool isCustomerIDExistDAL(Guid customerID)
        {
            List<Customer> customers = DeserializeFromJSON("Customerdata.txt");
            foreach(var cust in customers)
            {
                if (cust.CustomerID == customerID)
                    return true;
            }
            return false;
        }


        public bool SerialiazeIntoJSON(List<Customer> CustomersList, string FileName)
        {
            try
            {
                JsonSerializer serializer = new JsonSerializer();
                using (StreamWriter sw = new StreamWriter(FileName))   //filename is used so that we can have access over our own file
                using (JsonWriter writer = new JsonTextWriter(sw))
                {
                    serializer.Serialize(writer, CustomersList); // Serialize customers in customer.json
                    return true;
                }
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public List<Customer> DeserializeFromJSON(string FileName)
        {
            List<Customer> customers = JsonConvert.DeserializeObject<List<Customer>>(File.ReadAllText(FileName));// Done to read data from file
            using (StreamReader file = File.OpenText(FileName))
            {
                JsonSerializer serializer = new JsonSerializer();
                List<Customer> customers1 = (List<Customer>)serializer.Deserialize(file, typeof(List<Customer>));
                return customers1;
            }


        }
      
    }
}