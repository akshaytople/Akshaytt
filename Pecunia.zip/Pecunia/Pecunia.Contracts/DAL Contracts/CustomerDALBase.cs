﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;

namespace Pecunia.Contracts.DAL_Contracts
{
    public class CustomerDALBase
    {
        public void AddCustomerDAL(Customer newCustomer)
        {
            throw new NotImplementedException();
        }
    }
}
