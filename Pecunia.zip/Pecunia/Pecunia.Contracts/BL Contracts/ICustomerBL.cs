﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;


namespace Pecunia.Contracts.BL_Contracts
{
    public interface ICustomerBL
    {
    
        bool AddCustomerBL(Customer cust);
        bool RemoveCustomerBL(string customerID);
        Customer GetCustomerByCustomerIDBL(string customerID);
        List<Customer> GetAllCustomerDetails_BL();
        void UpdateCustomerByCustomerIDBL(Customer customerEntities, string customerID);



    }
}
