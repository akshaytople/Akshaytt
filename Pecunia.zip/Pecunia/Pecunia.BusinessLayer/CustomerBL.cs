﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using Pecunia.Contracts.BL_Contracts;
using Pecunia.Contracts.DAL_Contracts;
using Pecunia.DAL;

namespace Capgemini.Pecunia.BusinessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting  customer from Customers collection.
    /// </summary>
    public class CustomerBL : BLBase<Customer>, ICustomerBL , IDisposable
    {
        //fields
        CustomerDALBase CustomerDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public CustomerBL()
        {
            this.CustomerDAL = new CustomerDALBase();
        }

        /// <summary>
        /// Validations on data before adding or updating.
        /// </summary>
        /// <param name="entityObject">Represents object to be validated.</param>
        /// <returns>Returns a boolean value, that indicates whether the data is valid or not.</returns>
        protected async override Task<bool> Validate(Customer entityObject)
        {
            //Create string builder
            StringBuilder sb = new StringBuilder();
            bool valid = await base.Validate(entityObject);

            

            if (valid == false)
             throw new PecuniaException(sb.ToString());
            return valid;
        }

        /// <summary>
        /// Adds new customer to Customers collection.
        /// </summary>
        /// <param name="newCustomer">Contains the customer details to be added.</param>
        /// <returns>Determinates whether the new customer is added.</returns>
        public async Task<bool> AddCustomerBL(Customer newCustomer)
        {
            bool customerAdded = false;
            try
            {
                CustomerDAL custDAL = new CustomerDAL();
                {
                    await Task.Run(() =>
                    {
                        custDAL.AddCustomerDAL(newCustomer);
                        customerAdded = true;
                        
                    });
                }
            }
            catch (Exception)
            {
                throw;
            }
            return customerAdded;
        }

        /// <summary>
        /// Gets all suppliers from the collection.
        /// </summary>
        /// <returns>Returns list of all suppliers.</returns>
        public async Task<List<Customer>> GetAllCustomersBL()
        {
            List<Customer> customerList = null;
            try
            {
                CustomerDAL customerDAL = new CustomerDAL();

                await Task.Run(() =>
                {
                    customerList = customerDAL.GetAllCustomerDAL();
                });
            }
            catch (Exception)
            {
                throw;
            }
            return customerList;
        }

        /// <summary>
        /// Gets customer based on CustomerID.
        /// </summary>
        /// <param name="searchCustomerID">Represents CustomerID to search.</param>
        /// <returns>Returns Customer object.</returns>
        public async Task<Customer> GetCustomerByCustomerIDBL(Guid searchCustomerID)
        {
            CustomerDAL customerDAL = new CustomerDAL();
            Customer matchingCustomer = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingCustomer = customerDAL.GetCustomerByCustomerID_DAL(searchCustomerID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingCustomer;
        }

       

        /// <summary>
        /// Updates supplier based on CustomerID.
        /// </summary>
        /// <param name="updateCustomer">Represents Customer details including CustomerID, CustomerName etc.</param>
        /// <returns>Determinates whether the existing customer is updated.</returns>
        public async Task<bool> UpdateCustomerBL(Customer updateCustomer)
        {
            bool customerUpdated = false;
            try
            {
                await Task.Run(()=>
                {
                    CustomerDAL custDAL = new CustomerDAL();
                    if (custDAL.isCustomerIDExistDAL(updateCustomer.CustomerID) == true)
                    {
                        custDAL.UpdateCustomerByCustomerID_DAL(updateCustomer);
                    }

                }
            );
            catch (Exception)
            {
                throw;
            }
            return supplierUpdated;
        }

        /// <summary>
        /// Deletes customer based on CustomerID.
        /// </summary>
        /// <param name="removeCustomerID">Represents CustomerID to remove.</param>
        /// <returns>Determinates whether the existing customer is updated.</returns>
        public async Task<bool> RemoveCustomerBL(Guid removeCustomerID)
        {
            CustomerDAL customerDAL = new CustomerDAL();
            bool customerRemoved = false;
            try
            {
                await Task.Run(() =>
                {
                    CustomerDAL custDAL = new CustomerDAL();
                    if(custDAL.isCustomerIDExistDAL(removeCustomerID) == true)
                    {
                        customerRemoved =  custDAL.RemoveCustomerDAL(removeCustomerID);
                    }
                });
                return customerRemoved;
            }
            catch (Exception)
            {
                throw;
            }
            return customerRemoved;
        }

       

        /// <summary>
        /// Disposes DAL object(s).
        /// </summary>
        public void Dispose()
        {
            ((SupplierDAL)supplierDAL).Dispose();
        }

        /// <summary>
        /// Invokes Serialize method of DAL.
        /// </summary>
        
    }
}



