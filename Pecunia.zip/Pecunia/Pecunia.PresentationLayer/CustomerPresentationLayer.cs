﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using Pecunia.Entities;
using Pecunia.BL;


namespace Pecunia.PresentationLayer
{
    class CustomerPresentationLayer
    {
        void DisplayMenu()
        {

            Console.WriteLine("1.Add Customer\n2.Remove Customer\n3.GetCustomer By CustomerID\n4.Update Customer By Customer ID\n5.Display All Customers");
            int choice = int.Parse(ReadLine());
            switch (choice)
            {
                case 1:
                    AddCustomer();
                    break;
                case 2:
                    RemoveCustomer();
                    break;
                case 3:
                    GetCustomerByCustomerID();
                    break;
                case 4:
                    UpdateCustomerByCustomerID();
                    break;
                case 5:
                    DisplayAllCustomers();
                    break;
                default:
                    break;
            }
        }

        void AddCustomer()
        {
            CustomerEntities customerEntities = new CustomerEntities();
            Console.WriteLine("Enter Name");
            customerEntities.CustomerName = ReadLine();
            Console.WriteLine("Enter Mobile number");
            customerEntities.CustomerMobile = ReadLine();
            Console.WriteLine("Enter Address");
            customerEntities.CustomerAddress = ReadLine();

            Console.WriteLine("Enter Email");
            customerEntities.CustomerEmail = ReadLine();

            Console.WriteLine("Enter PAN");
            customerEntities.CustomerPan = ReadLine();

            CustomerBL cbl = new CustomerBL();
            cbl.AddCustomerBL(customerEntities);
        }

        void RemoveCustomer()
        {
            CustomerBL customerBL = new CustomerBL();
            Console.WriteLine("Enter CustomerID to remove Customer");
            string customerID = ReadLine();
            customerBL.RemoveCustomerBL(customerID);
            
        }
        void GetCustomerByCustomerID()
        {
            Console.WriteLine("ENter Customer ID");
            string customerID = ReadLine();
            CustomerBL customerBL = new CustomerBL();
            CustomerEntities customerEntities = new CustomerEntities();
            customerEntities = customerBL.GetCustomerByCustomerIDBL(customerID);
            Console.WriteLine(customerEntities.CustomerName);
            Console.WriteLine(customerEntities.CustomerEmail);
            Console.WriteLine(customerEntities.CustomerMobile);
            Console.WriteLine(customerEntities.CustomerID);

        }
               
                    void UpdateCustomerByCustomerID()
        {
            Console.WriteLine("Enter CustomerID");
            string customerID = ReadLine();
            CustomerEntities customerEntities = new CustomerEntities();
            Console.WriteLine("Enter Name");
            customerEntities.CustomerName = ReadLine();
            Console.WriteLine("Enter Mobile number");
            customerEntities.CustomerMobile = ReadLine();
            Console.WriteLine("Enter Address");
            customerEntities.CustomerAddress = ReadLine();

            Console.WriteLine("Enter Email");
            customerEntities.CustomerEmail = ReadLine();

            Console.WriteLine("Enter PAN");
            customerEntities.CustomerPan = ReadLine();

            CustomerBL customerBL = new CustomerBL();
            customerBL.UpdateCustomerByCustomerIDBL(customerEntities, customerID);
        }

        void DisplayAllCustomers()
        {
            List<CustomerEntities> customerEntitiesList = new List<CustomerEntities>();
            CustomerBL customerBL = new CustomerBL();
            customerEntitiesList = customerBL.GetAllCustomerDetails_BL();

            foreach (CustomerEntities index in customerEntitiesList)
            {
                Console.WriteLine("Customer name "+index.CustomerName);
                Console.WriteLine("Customer Email " + index.CustomerEmail);
                Console.WriteLine("Customer PAN " + index.CustomerPan);
                Console.WriteLine("Customer Mobile " + index.CustomerMobile);
                Console.WriteLine("Customer Address " + index.CustomerAddress);
                Console.WriteLine("------------------------------------------------------------------------------------");
            }
        }

    }
}
