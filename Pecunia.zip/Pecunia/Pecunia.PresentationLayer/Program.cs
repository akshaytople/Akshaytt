﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.BusinessLayer;
using Pecunia.Entities;
using static System.Console;
using Pecunia.BL;
using Pecunia.Entities;
namespace Pecunia.PresentationLayer
  
{
    class Program
    {
        static void Main(string[] args)
        {
            AccountBL a = new AccountBL();

            //List<Account> La = new List<Account>();
            //a.AddAccountBL("Savings", 50000, "Pune","11111111111111");
            //a.AddAccountBL("Current", 50000, "Pune", "11111111111112");
            //a.AddAccountBL("FD", 50000, "Pune", "11111111111111");
            ////if (a.DeleteAccount(5000, "Faltu"))
            ////{
            ////    Console.WriteLine("Zalay");
            ////}
            //La = a.GetAllAccountsBL();
            //foreach (Account ac in La)
            //{
            //    Console.WriteLine(ac.HomeBranch);
            //    Console.WriteLine(ac._accType);
            //    Console.WriteLine(ac.InitialAmount);
            //    Console.WriteLine(ac.AccountNo);
            //    Console.WriteLine(ac.CustomerID);
            //}




            //CustomerEntities c1 = new CustomerEntities();

            //c1 = cbl.GetCustomerByCustomerID_BL("20190921075408");
            //Console.WriteLine(c1.CustomerName);
            //Console.WriteLine(c1.CustomerID);
            DIsplayMenu();

            void DIsplayMenu()
            {
                Console.WriteLine("1.Add Account\n2.Remove Account\n3.Update AAccount\n4.GetAccountByCustomerID\n5.GetAccountByAccountNumber\n6.Display All Accounts");
                int choice;
                choice = int.Parse(ReadLine());
                switch (choice)
                {
                    case 1:
                        AddAccount();
                        break;
                    case 2:
                        RemoveAccount();
                        break;

                    case 3:
                        UpdateAccount();
                        break;
                    case 4:
                        GetAccountByCustomerID();
                        break;
                    case 5:
                        GetAccountByAccountNumber();
                        break;
                    case 6:
                        DisplayAllAccounts();
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            }
           

             void AddAccount()
            {
                Console.WriteLine("1. Existing Customer\n 2. New Customer");
                int choice1 = int.Parse(ReadLine());
                switch (choice1)
                {
                    case 1:
                        Console.WriteLine("Enter Account Type");
                        string accountType = ReadLine();
                        Console.WriteLine("Enter Initial Amount");
                        double initialAmount = double.Parse(ReadLine());
                        Console.WriteLine("Enter Home Branch");
                        string homeBranch = ReadLine();
                        Console.WriteLine("Enter CustomerID");
                        string customerID = ReadLine();
                         AccountBL accountBL = new AccountBL();
                        if (accountBL.AddAccountBL(accountType, initialAmount, homeBranch, customerID))
                        {
                            Console.WriteLine("Account Added Sucessfully");
                            DIsplayMenu();
                        } 
                        else
                            Console.WriteLine("Account Not Added");

                        break;

                    case 2:
                        Customer c = new Customer();
                        Console.WriteLine("Enter Name");
                        c.CustomerName = ReadLine();
                        Console.WriteLine("Enter Mobile number");
                        c.CustomerMobile = ReadLine();
                        Console.WriteLine("Enter Address");
                        c.CustomerAddress = ReadLine();

                        Console.WriteLine("Enter Email");
                        c.CustomerEmail = ReadLine();

                        Console.WriteLine("Enter PAN");
                        c.CustomerPan = ReadLine();

                        CustomerBL cbl = new CustomerBL();
                        cbl.AddCustomerBL(c);
                        Console.WriteLine("Enter Account Type");
                        string accountTypenew = ReadLine();
                        Console.WriteLine("Enter Initial Amount");
                        double initialAmountnew = double.Parse(ReadLine());
                        Console.WriteLine("Enter Home Branch");
                        string homeBranchnew = ReadLine();

                        AccountBL accountBL2 = new AccountBL();
                        if (accountBL2.AddAccountBL(accountTypenew, initialAmountnew, homeBranchnew, c.CustomerID))
                        {
                            Console.WriteLine("Account Added SUccessfully\n");
                            DIsplayMenu();
                        }

                        // Call the Function which displays main

                        break;


                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
               

            }

            void UpdateAccount()
            {
                Console.WriteLine("1.Update Account Type\n 2. Update Home Branch\n 3.Update FD Amount\n");
                int choice2 = int.Parse(ReadLine());
                switch (choice2)
                {
                    case 1:
                        Console.WriteLine("Enter Account Number");
                        long accountNumber = long.Parse(ReadLine());
                        Console.WriteLine("Enter New Account Type(Only Current and Savings can be interchanged FD Cannot be converted)");
                        string accountType = ReadLine();
                        AccountBL accountBL = new AccountBL();
                        if (accountBL.ChangeAccountTypeBL(accountNumber, accountType))

                        {
                            Console.WriteLine("Account Type CHanged");
                            DIsplayMenu();
                        }
                        else
                        {
                            Console.WriteLine("Error while changing Account");
                            DIsplayMenu();
                        }
                        break;

                    case 2:
                        Console.WriteLine("Enter AccountNumber");
                        long accountNumber1 = long.Parse(ReadLine());
                        Console.WriteLine("Enter Home Branch");
                        string homeBranch = ReadLine();
                        AccountBL accountBL1 = new AccountBL();
                        accountBL1.ChangeBranchBL(accountNumber1, homeBranch);
                        break;
                    case 3:
                        Console.WriteLine("Enter new FD Amount");
                        double fdAmount = double.Parse(ReadLine());
                        Console.WriteLine("Enter Account Number");
                        long accountNumber2 = long.Parse(ReadLine());
                        AccountBL accountBL2 = new AccountBL();
                        if (accountBL2.UpdateFDAmountBL(accountNumber2, fdAmount))
                        {
                            Console.WriteLine("FD Amount Updated");
                            DIsplayMenu();
                        }
                        else
                        {
                            Console.WriteLine("AMount Not Updated");
                            DIsplayMenu();
                        }
                        break;




                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }

            }
            void RemoveAccount()
            {
                Console.WriteLine("ENter Account Number");
                long accountNumber = long.Parse(ReadLine());
                Console.WriteLine("Please Give your FeedBack why you want to delete the Account");
                string feedback = ReadLine();
                AccountBL accountBL= new AccountBL();
                if (accountBL.DeleteAccount(accountNumber, feedback))
                {
                    Console.WriteLine("Account Deleted Successfully");
                    DIsplayMenu();
                }
                else
                {
                    Console.WriteLine("Error while Deleting Account");
                    DIsplayMenu();
                }
            }
            void GetAccountByCustomerID()
            {
                Console.WriteLine("Enter CustomerID");
                string customerID = ReadLine();
                AccountBL accountBL = new AccountBL();
                CustomerBL customerBL = new CustomerBL();
                List<Account> accountList = new List<Account>();
                Customer customerEntities = new Customer();
                customerEntities = customerBL.GetCustomerByCustomerID_BL(customerID);
               
                accountList = accountBL.GetAccountByCustomerIDBL(customerID);

                foreach(Account acc in accountList)

                {
                    if ((int)acc._accType == 2)
                    {
                        Console.WriteLine("Customer name - " + customerEntities.CustomerName);
                        Console.WriteLine("Customer Account Number " + acc.AccountNo);
                        Console.WriteLine("Customer FD Amount "+acc.FdDeposit);
                        Console.WriteLine("Customer Branch "+acc.HomeBranch);
                  
                    }
                    else
                    {
                        Console.WriteLine("Customer name - " + customerEntities.CustomerName);
                        Console.WriteLine("Customer Account Number " + acc.AccountNo);
                        Console.WriteLine("Customer Balance " + acc.Balance);
                        Console.WriteLine("Customer Branch " + acc.HomeBranch);
                        
                    }
                   
                }
                DIsplayMenu();


            }
            void GetAccountByAccountNumber()
            {
                Console.WriteLine("Enter Account Number");
                long accountNumber = long.Parse(ReadLine());
                AccountBL accountBL = new AccountBL();
                Account account = new Account();
                account=accountBL.GetAccountByAccountNoBL(accountNumber);
                if ((int)account._accType == 2)
                {
                    
                    Console.WriteLine("Customer Account Number " + account.AccountNo);
                    Console.WriteLine("Customer FD Amount " + account.FdDeposit);
                    Console.WriteLine("Customer Branch " + account.Branch);
                   
                }
                else
                {
                   
                    Console.WriteLine("Customer Account Number " + account.AccountNo);
                    Console.WriteLine("Customer Balance " + account.Balance);
                    Console.WriteLine("Customer Branch " + account.Branch);
                
                }
                DIsplayMenu();
            }
            void DisplayAllAccounts()
            {
                List<Account> accountList = new List<Account>();
                AccountBL accountBL = new AccountBL();
                accountList = accountBL.GetAllAccountsBL();
                foreach(Account acc in accountList)
                {
                    if ((int)acc._accType == 2)
                    {
                        
                      Console.WriteLine("Customer Account Number " + acc.AccountNo);
                        Console.WriteLine("Customer FD Amount " + acc.FdDeposit);
                       Console.WriteLine("Customer Branch " + acc.HomeBranch);
                     Console.WriteLine("Customer Account Type "+acc._accType);
                        Console.WriteLine("--------------------------------------------------------------------------");
                    
                    }
                    else
                    
                       
                        Console.WriteLine("Customer Account Number " + acc.AccountNo);
                        Console.WriteLine("Customer Balance " + acc.Balance);
                        Console.WriteLine("Customer Branch " + acc.HomeBranch);
                        Console.WriteLine("Customer Account Type " + acc._accType);
                        Console.WriteLine("--------------------------------------------------------------------------");
                       
                    
                }
                DIsplayMenu();
            }
            


        }

    }

}
