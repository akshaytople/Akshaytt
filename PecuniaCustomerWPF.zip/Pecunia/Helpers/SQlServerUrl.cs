﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Helpers
{
    public class SQlServerUrl
    {
        public static SqlConnection getsqlconnection(string serverName, string databaseName, string user, string password)
        {
            string connectstring = $"Data Source ={serverName};Initial Catalog={databaseName};User ID={user};Password={password}";
            SqlConnection con = new SqlConnection(connectstring);
            return con;
        }

    }
}
