﻿using Capgemini.Pecunia.BusinessLayer;
using Capgemini.Pecunia.Entities;
using Capgemini.Pecunia.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
   
    class Program
    {
        [STAThread]
        public static void Main()
        {
            Proram.Test().Wait();
        }
    }

    public class Proram
    {
        public static async Task Test()
        {
           CustomerBL customerBL = new CustomerBL();
            List<Customer> customers = new List<Customer>();
            Guid custId;
            Guid.TryParse("9D71F374-FCE3-4DF3-B5A4-3709B99AC22", out custId);
            Customer customer = new Customer();
            customer  = await customerBL.GetCustomerByCustomerIDBL(custId);
            Console.WriteLine(customer.CustomerMobile);
            if(customer == default(Customer))
                Console.WriteLine( "yesr");
            else
                Console.WriteLine("no");
            //foreach(Customer cust in customers)
            //{
            //    Console.WriteLine(cust.CustomerID);
            //}

        
        }
    }
}
